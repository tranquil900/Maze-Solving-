from stable_baselines.common.policies import MlpPolicy
from stable_baselines.common.vec_env import DummyVecEnv
from stable_baselines import PPO2
from MazeEnv import MazeEnvironment
import argparse
import numpy as np
from typing import List
import time

epochs = 1000000
lr = 0.001
gamma = 0.000001
lam = 0
world = [[1, 0, 2, 0, 0],[0, 0, 0, 0, 0],[4, 0, 0, 0, 0],[0, 0, 3, 3, 0],[0, 0, 3, 5, 0]]
inference = True

maze_env = DummyVecEnv([lambda: MazeEnvironment(np.array(world))])
model = PPO2(MlpPolicy,
             maze_env,
             learning_rate=lr,
             gamma=gamma,
             lam=lam)
print(f"Training agents for {epochs//30} episodes.")
start = time.time()
model.learn(epochs)
end = time.time()

if inference is True:
    print(f"Training complete. Duration: {end-start} seconds.")
    print(f"Testing results. Getting Number of Wins for 300 steps...")
    result_test = []
    obs = maze_env.reset()
    for i in range(300):
        action, _states = model.predict(obs)
        obs, reward, done, info = maze_env.step(action)
        if done:
            result_test.append(info[0]['state'])
    score = result_test.count('W')/len(result_test)
    print(f"Inference test complete. Performance score: {score * 100} %")

